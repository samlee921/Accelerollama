# Audio file

import pygame as pg

pg.mixer.init()
pg.mixer.music.load('/home/pi/Desktop/Laser Dogs/myfile.wav')
pg.mixer.music.set_volume(1.0)
pg.mixer.music.play()


# Accelerometer
import time
import board
import busio
import adafruit_msa301


i2c = busio.I2C(board.SCL, board.SDA)
msa = adafruit_msa301.MSA301(i2c)

while True:
    # print("%f %f %f" % msa.acceleration)

    if msa.acceleration[0]> 0:
        playsound('myfile.wav') # Replace with the audio file name
        print("meow beow")
    elif msa.acceleration[1] > 0:
       playsound('myfile.wav')
    elif msa.acceleration [2] > 0:
        playsound('myfile.wav')
       

    time.sleep(1)