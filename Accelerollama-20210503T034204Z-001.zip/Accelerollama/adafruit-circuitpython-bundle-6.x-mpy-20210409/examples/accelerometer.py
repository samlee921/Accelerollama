import time
import board
import busio
import adafruit_msa301

#from playsound import playsound


i2c = busio.I2C(board.SCL, board.SDA)
msa = adafruit_msa301.MSA301(i2c)

while True:
    # print("%f %f %f" % msa.acceleration)

    if msa.acceleration[0]> 0:
        #playsound('myfile.wav') # Replace with the audio file name
        print("meow beow")
    elif msa.acceleration[1] > 0:
        print("meow bitches")
       #playsound('myfile.wav')
    elif msa.acceleration [2] > 0:
        print("moo moo")
        #playsound('myfile.wav')
       

    time.sleep(1)