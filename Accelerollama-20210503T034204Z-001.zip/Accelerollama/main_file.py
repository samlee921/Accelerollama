import time
import board
import busio
import math
import numpy
np = numpy
import adafruit_drv2605
import adafruit_msa301

i2c = busio.I2C(board.SCL, board.SDA)

drv = adafruit_drv2605.DRV2605(i2c)
msa = adafruit_msa301.MSA301(i2c)


mag = []

while True:
    
    x=0
    for x in range (5):
        magnitude = numpy.sqrt(msa.acceleration[0]**2+msa.acceleration[1]**2+msa.acceleration[2]**2)
        mag.insert(x,magnitude)
        time.sleep(0.2)
        x+=1

        
    print(mag)
    #print(np.std(mag))
        
    magnitude = numpy.sqrt(msa.acceleration[0]**2+msa.acceleration[1]**2+msa.acceleration[2]**2)
    print(magnitude)
    if 1 < np.std(mag):
        drv.sequence[0] = adafruit_drv2605.Effect(58)
        drv.play()
        time.sleep(1) # Buzz for 1 second
        drv.stop()
        mag.clear()
        
    
    if 17 < magnitude < 30:
        drv.sequence[0] = adafruit_drv2605.Effect(118)
        drv.play()
        time.sleep(2)
        drv.stop()
        
    time.sleep(0.3)
    mag.clear()    